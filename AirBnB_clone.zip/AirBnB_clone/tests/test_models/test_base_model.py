#!/usr/bin/python3
"""Unit tests for models.base_model.BaseModel."""
import unittest
from datetime import datetime
from time import sleep
from models.base_model import BaseModel


class TestBaseModel(unittest.TestCase):
    """Test cases for the BaseModel class."""

    def test_unique_id(self):
        b1 = BaseModel()
        b2 = BaseModel()
        self.assertNotEqual(b1.id, b2.id)

    def test_id_is_str(self):
        self.assertIsInstance(BaseModel().id, str)

    def test_created_at_is_datetime(self):
        self.assertIsInstance(BaseModel().created_at, datetime)

    def test_updated_at_is_datetime(self):
        self.assertIsInstance(BaseModel().updated_at, datetime)

    def test_str_representation(self):
        b = BaseModel()
        self.assertEqual(
            str(b),
            "[BaseModel] ({}) {}".format(b.id, b.__dict__),
        )

    def test_save_updates_updated_at(self):
        b = BaseModel()
        old_updated_at = b.updated_at
        sleep(0.01)
        b.save()
        self.assertGreater(b.updated_at, old_updated_at)

    def test_to_dict_is_dict(self):
        self.assertIsInstance(BaseModel().to_dict(), dict)

    def test_to_dict_contains_class_key(self):
        d = BaseModel().to_dict()
        self.assertEqual(d["__class__"], "BaseModel")

    def test_to_dict_datetimes_are_strings(self):
        d = BaseModel().to_dict()
        self.assertIsInstance(d["created_at"], str)
        self.assertIsInstance(d["updated_at"], str)

    def test_init_from_dict_roundtrip(self):
        b = BaseModel()
        b.name = "Test"
        b.number = 42
        d = b.to_dict()
        b2 = BaseModel(**d)
        self.assertEqual(b.id, b2.id)
        self.assertEqual(b.created_at, b2.created_at)
        self.assertEqual(b.updated_at, b2.updated_at)
        self.assertEqual(b.name, b2.name)
        self.assertEqual(b.number, b2.number)
        self.assertIsNot(b, b2)

    def test_init_from_dict_datetimes_are_datetime_objects(self):
        b = BaseModel()
        d = b.to_dict()
        b2 = BaseModel(**d)
        self.assertIsInstance(b2.created_at, datetime)
        self.assertIsInstance(b2.updated_at, datetime)

    def test_class_key_not_set_as_attribute(self):
        b = BaseModel()
        d = b.to_dict()
        b2 = BaseModel(**d)
        self.assertNotEqual(getattr(b2, "__class__"), "BaseModel")
        self.assertEqual(type(b2).__name__, "BaseModel")


if __name__ == "__main__":
    unittest.main()
