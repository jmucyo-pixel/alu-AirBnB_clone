#!/usr/bin/python3
"""Unit tests for models.review.Review."""
import unittest
from models.base_model import BaseModel
from models.review import Review


class TestReview(unittest.TestCase):
    """Test cases for the Review class."""

    def test_is_subclass_of_base_model(self):
        self.assertIsInstance(Review(), BaseModel)

    def test_default_attributes(self):
        r = Review()
        self.assertEqual(r.place_id, "")
        self.assertEqual(r.user_id, "")
        self.assertEqual(r.text, "")


if __name__ == "__main__":
    unittest.main()
