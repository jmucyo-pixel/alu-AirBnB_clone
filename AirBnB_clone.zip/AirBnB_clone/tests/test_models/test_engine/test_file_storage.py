#!/usr/bin/python3
"""Unit tests for models.engine.file_storage.FileStorage."""
import json
import os
import unittest
from models import storage
from models.base_model import BaseModel
from models.user import User


class TestFileStorage(unittest.TestCase):
    """Test cases for the FileStorage class."""

    def test_all_returns_dict(self):
        self.assertIsInstance(storage.all(), dict)

    def test_new_adds_object_with_correct_key(self):
        b = BaseModel()
        key = "BaseModel.{}".format(b.id)
        self.assertIn(key, storage.all())
        self.assertIs(storage.all()[key], b)

    def test_save_writes_json_file(self):
        storage.save()
        self.assertTrue(os.path.exists("file.json"))
        with open("file.json") as f:
            data = json.load(f)
        self.assertIsInstance(data, dict)

    def test_reload_restores_objects(self):
        u = User()
        u.email = "test@example.com"
        u.save()
        key = "User.{}".format(u.id)

        storage.reload()

        self.assertIn(key, storage.all())
        reloaded = storage.all()[key]
        self.assertEqual(reloaded.id, u.id)
        self.assertEqual(reloaded.email, "test@example.com")

    def test_reload_missing_file_does_not_raise(self):
        path = storage._FileStorage__file_path
        if os.path.exists(path):
            os.rename(path, path + ".bak")
        try:
            storage.reload()  # should not raise
        finally:
            if os.path.exists(path + ".bak"):
                os.rename(path + ".bak", path)


if __name__ == "__main__":
    unittest.main()
