#!/usr/bin/python3
"""Unit tests for models.user.User."""
import unittest
from models.base_model import BaseModel
from models.user import User


class TestUser(unittest.TestCase):
    """Test cases for the User class."""

    def test_is_subclass_of_base_model(self):
        self.assertIsInstance(User(), BaseModel)

    def test_default_attributes(self):
        u = User()
        self.assertEqual(u.email, "")
        self.assertEqual(u.password, "")
        self.assertEqual(u.first_name, "")
        self.assertEqual(u.last_name, "")

    def test_attributes_are_strings(self):
        for attr in ("email", "password", "first_name", "last_name"):
            self.assertIsInstance(getattr(User(), attr), str)


if __name__ == "__main__":
    unittest.main()
