#!/usr/bin/python3
"""Unit tests for models.city.City."""
import unittest
from models.base_model import BaseModel
from models.city import City


class TestCity(unittest.TestCase):
    """Test cases for the City class."""

    def test_is_subclass_of_base_model(self):
        self.assertIsInstance(City(), BaseModel)

    def test_default_attributes(self):
        c = City()
        self.assertEqual(c.state_id, "")
        self.assertEqual(c.name, "")


if __name__ == "__main__":
    unittest.main()
