#!/usr/bin/python3
"""Unit tests for models.state.State."""
import unittest
from models.base_model import BaseModel
from models.state import State


class TestState(unittest.TestCase):
    """Test cases for the State class."""

    def test_is_subclass_of_base_model(self):
        self.assertIsInstance(State(), BaseModel)

    def test_default_name(self):
        self.assertEqual(State().name, "")


if __name__ == "__main__":
    unittest.main()
