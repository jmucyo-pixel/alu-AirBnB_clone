#!/usr/bin/python3
"""Unit tests for models.amenity.Amenity."""
import unittest
from models.base_model import BaseModel
from models.amenity import Amenity


class TestAmenity(unittest.TestCase):
    """Test cases for the Amenity class."""

    def test_is_subclass_of_base_model(self):
        self.assertIsInstance(Amenity(), BaseModel)

    def test_default_name(self):
        self.assertEqual(Amenity().name, "")


if __name__ == "__main__":
    unittest.main()
