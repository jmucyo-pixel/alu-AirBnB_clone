# AirBnB Clone - The Console

A command-line interpreter for managing AirBnB clone objects (`BaseModel`,
`User`, `State`, `City`, `Amenity`, `Place`, `Review`), with a JSON-file
storage engine for persistence between sessions.

## Usage

Interactive mode:
```bash
./console.py
(hbnb) create User
(hbnb) all User
(hbnb) show User <id>
(hbnb) update User <id> first_name "Betty"
(hbnb) destroy User <id>
(hbnb) quit
```

Non-interactive mode:
```bash
echo "create User" | ./console.py
```

## Commands
| Command | Usage | Description |
|---|---|---|
| `create` | `create <class>` | Creates a new instance, saves it, prints its id |
| `show` | `show <class> <id>` | Prints the string representation of an instance |
| `destroy` | `destroy <class> <id>` | Deletes an instance and saves the change |
| `all` | `all [class]` | Prints all instances, optionally filtered by class |
| `update` | `update <class> <id> <attr> "<value>"` | Updates or adds an attribute |
| `quit` / `EOF` | | Exits the program |

## Storage
All objects are serialized to `file.json` in the current directory. On
startup, `models/__init__.py` creates a single `FileStorage` instance
(`storage`) and reloads any existing data.

## Running tests
```bash
python3 -m unittest discover tests
```

## Project structure
```
.
├── console.py
├── models/
│   ├── __init__.py
│   ├── base_model.py
│   ├── user.py
│   ├── state.py
│   ├── city.py
│   ├── amenity.py
│   ├── place.py
│   ├── review.py
│   └── engine/
│       ├── __init__.py
│       └── file_storage.py
└── tests/
    └── test_models/
        ├── test_base_model.py
        ├── test_user.py
        ├── test_state.py
        ├── test_city.py
        ├── test_amenity.py
        ├── test_place.py
        ├── test_review.py
        └── test_engine/
            └── test_file_storage.py
```
