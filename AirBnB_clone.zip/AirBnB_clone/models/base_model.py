#!/usr/bin/python3
"""Defines the BaseModel class, the base for all other models."""
import uuid
from datetime import datetime
import models

TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"


class BaseModel:
    """Represents the base model with common attributes/methods."""

    def __init__(self, *args, **kwargs):
        """Initialize a new BaseModel, or recreate one from a dict.

        Args:
            *args: unused.
            **kwargs: if not empty, attribute name/value pairs used to
                recreate an instance (e.g. from to_dict()). created_at and
                updated_at are converted back from ISO strings to datetime
                objects. __class__ is ignored - it is metadata, not an
                attribute to restore.
        """
        if kwargs:
            for key, value in kwargs.items():
                if key == "__class__":
                    continue
                if key in ("created_at", "updated_at"):
                    value = datetime.strptime(value, TIME_FORMAT)
                setattr(self, key, value)
        else:
            self.id = str(uuid.uuid4())
            self.created_at = datetime.now()
            self.updated_at = datetime.now()
            models.storage.new(self)

    def __str__(self):
        """Return the string representation of the instance."""
        return "[{}] ({}) {}".format(
            type(self).__name__, self.id, self.__dict__
        )

    def save(self):
        """Update updated_at with the current datetime and persist to
        storage."""
        self.updated_at = datetime.now()
        models.storage.save()

    def to_dict(self):
        """Return a dictionary representation of the instance.

        Includes all instance attributes, a `__class__` key set to the
        class name, and `created_at`/`updated_at` converted to ISO
        format strings.
        """
        dict_representation = self.__dict__.copy()
        dict_representation["__class__"] = type(self).__name__
        dict_representation["created_at"] = self.created_at.isoformat()
        dict_representation["updated_at"] = self.updated_at.isoformat()
        return dict_representation
